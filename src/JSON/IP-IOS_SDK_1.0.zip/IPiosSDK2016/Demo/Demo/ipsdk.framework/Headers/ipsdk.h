//
//  ipsdk.h
//  ipsdk
//
//  Created by MAC-01 on 8/6/15.
//  Copyright (c) 2015 MAC-01. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ipsdk.
FOUNDATION_EXPORT double ipsdkVersionNumber;

//! Project version string for ipsdk.
FOUNDATION_EXPORT const unsigned char ipsdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ipsdk/PublicHeader.h>

#import <ipsdk/IPBannerView.h>
#import <ipsdk/IPVideoInterstitialViewController.h>


