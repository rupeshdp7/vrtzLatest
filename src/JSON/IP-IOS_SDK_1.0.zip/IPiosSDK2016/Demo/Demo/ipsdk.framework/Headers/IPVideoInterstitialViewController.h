

#import <UIKit/UIKit.h>

enum {
    IPInterstitialViewErrorUnknown = 0,
    IPInterstitialViewErrorServerFailure = 1,
    IPInterstitialViewErrorInventoryUnavailable = 2,
};

typedef enum {
    IPAdTypeNoAdInventory = 0,
    IPAdTypeVideo = 1,
    IPAdTypeError = 2,
    IPAdTypeUnknown = 3,
    IPAdTypeText = 4,
    IPAdTypeImage = 5,
    IPAdTypeMraid = 6
    
} IPAdType;

typedef enum {
    IPAdGroupVideo = 0,
    IPAdGroupInterstitial = 1
} IPAdGroupType;

@class IPVideoInterstitialViewController;
@class IPAdBrowserViewController;

@protocol IPVideoInterstitialViewControllerDelegate <NSObject>

- (NSString *)publisherIdForIPVideoInterstitialView:(IPVideoInterstitialViewController *)videoInterstitial;

@optional

- (void)IPVideoInterstitialViewDidLoadIPAd:(IPVideoInterstitialViewController *)videoInterstitial advertTypeLoaded:(IPAdType)advertType;

- (void)IPVideoInterstitialView:(IPVideoInterstitialViewController *)videoInterstitial didFailToReceiveAdWithError:(NSError *)error;

- (void)IPVideoInterstitialViewActionWillPresentScreen:(IPVideoInterstitialViewController *)videoInterstitial;

- (void)IPVideoInterstitialViewWillDismissScreen:(IPVideoInterstitialViewController *)videoInterstitial;

- (void)IPVideoInterstitialViewDidDismissScreen:(IPVideoInterstitialViewController *)videoInterstitial;

- (void)IPVideoInterstitialViewActionWillLeaveApplication:(IPVideoInterstitialViewController *)videoInterstitial;

- (void)IPVideoInterstitialViewWasClicked:(IPVideoInterstitialViewController *)videoInterstitial;

@end

@interface IPVideoInterstitialViewController : UIViewController
{

    BOOL advertLoaded;
	BOOL advertViewActionInProgress;

    __unsafe_unretained id <IPVideoInterstitialViewControllerDelegate> delegate;

    IPAdBrowserViewController *_browser;

    NSString *requestURL;
    NSString *videoRequestURL;
    UIImage *_bannerImage;

}

@property (nonatomic, assign) IBOutlet __unsafe_unretained id <IPVideoInterstitialViewControllerDelegate> delegate;

@property (nonatomic, readonly, getter=isAdvertLoaded) BOOL advertLoaded;
@property (nonatomic, readonly, getter=isAdvertViewActionInProgress) BOOL advertViewActionInProgress;

@property (nonatomic, assign) BOOL locationAwareAdverts;
@property (nonatomic, assign) BOOL enableInterstitialAds;
@property (nonatomic, assign) BOOL enableVideoAds;
@property (nonatomic, assign) BOOL prioritizeVideoAds;
@property (nonatomic, assign) NSInteger video_min_duration;
@property (nonatomic, assign) NSInteger video_max_duration;

@property (nonatomic, assign) NSInteger userAge;
@property (nonatomic, strong) NSString* userGender;
@property (nonatomic, retain) NSArray* keywords;

@property (nonatomic, strong) NSString *requestURL;

- (void)requestAd;

- (void)presentAd:(IPAdType)advertType;

- (void)setLocationWithLatitude:(CGFloat)latitude longitude:(CGFloat)longitude;


@end

//extern NSString * const IPVideoInterstitialErrorDomain;