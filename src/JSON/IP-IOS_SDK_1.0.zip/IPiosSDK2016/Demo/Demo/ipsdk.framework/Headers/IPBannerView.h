

#import <UIKit/UIKit.h>

enum {
    IPErrorUnknown = 0,
    IPErrorServerFailure = 1,
    IPErrorInventoryUnavailable = 2,
};

@class IPBannerView;

@protocol IPBannerViewDelegate <NSObject>

- (NSString *)publisherIdForIPBannerView:(IPBannerView *)banner;

@optional

- (void)IPBannerViewDidLoadIPAd:(IPBannerView *)banner;

- (void)IPBannerViewDidLoadRefreshedAd:(IPBannerView *)banner;

- (void)IPBannerView:(IPBannerView *)banner didFailToReceiveAdWithError:(NSError *)error;

- (BOOL)IPBannerViewActionShouldBegin:(IPBannerView *)banner willLeaveApplication:(BOOL)willLeave;

- (void)IPBannerViewActionWillPresent:(IPBannerView *)banner;

- (void)IPBannerViewActionWillFinish:(IPBannerView *)banner;

- (void)IPBannerViewActionDidFinish:(IPBannerView *)banner;

- (void)IPBannerViewActionWillLeaveApplication:(IPBannerView *)banner;

@end

@interface IPBannerView : UIView 
{
	NSString *advertisingSection;
	BOOL bannerLoaded;
	BOOL bannerViewActionInProgress;

	BOOL _tapThroughLeavesApp;
	BOOL _shouldScaleWebView;
	BOOL _shouldSkipLinkPreflight;
	BOOL _statusBarWasVisible;
	NSURL *_tapThroughURL;
    NSInteger _refreshInterval;
	NSTimer *_refreshTimer;

}

@property (nonatomic, assign) IBOutlet __unsafe_unretained id <IPBannerViewDelegate> delegate;//Instance variable for this delegate
@property (nonatomic, copy) NSString *advertisingSection;
@property (nonatomic, assign) UIViewAnimationTransition refreshAnimation;//ios class in UIView.h

@property (nonatomic, assign) NSInteger adspaceWidth;
@property (nonatomic, assign) NSInteger adspaceHeight;
@property (nonatomic, assign) BOOL adspaceStrict;

@property (nonatomic, readonly, getter=isBannerLoaded) BOOL bannerLoaded;//ios class in ADBannerView.h,Check  whether banner has downloaded a  banner Ad .
@property (nonatomic, readonly, getter=isBannerViewActionInProgress) BOOL bannerViewActionInProgress;//ios class in ADBannerView.h,Check  whether any banner Ad is running presently.
@property (nonatomic, assign) BOOL refreshTimerOff;
@property (nonatomic, assign) NSInteger customReloadTime;
@property (nonatomic, retain) UIImage *_bannerImage;
@property (strong, nonatomic) NSString *requestURL;



@property (nonatomic, assign) NSInteger userAge;
@property (nonatomic, strong) NSString* userGender;
@property (nonatomic, retain) NSArray* keywords;

@property (nonatomic, assign) BOOL allowDelegateAssigmentToRequestAd;

@property (nonatomic, assign) BOOL locationAwareAdverts;
//s2s
@property(nonatomic,assign) NSString *hrefValue;
@property(nonatomic,assign) NSString *srcValue;
@property(nonatomic,assign) NSString *htmlValue;



- (void)setLocationWithLatitude:(CGFloat)latitude longitude:(CGFloat)longitude;

- (void)requestAd;


@end

extern NSString * const IPErrorDomain;