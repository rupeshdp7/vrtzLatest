//
//  ViewController.m
//  Demo
//
//  Created by Macmini - Vertoz on 9/21/15.
//  Copyright (c) 2015 Macmini - Vertoz. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize bannerView,videoInterstitialViewController;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.videoInterstitialViewController = [[IPVideoInterstitialViewController alloc] init]; self.videoInterstitialViewController.delegate = self;
    [self.view addSubview:self.videoInterstitialViewController.view];

    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)Banner:(id)sender
{
    if (!self.bannerView)
    {
        self.bannerView = [[IPBannerView alloc]initWithFrame:CGRectZero]; self.bannerView.allowDelegateAssigmentToRequestAd = NO; self.bannerView.delegate = self;
        self.bannerView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:self.bannerView]; }
    [self.bannerView requestAd];
}
-(BOOL)isBannerViewInHiearchy {
    for (UIView *oneView in self.view.subviews) {
        if(oneView == self.bannerView) {
            return YES; }
    }
    return NO; }

-(void)slideInBannerView:(IPBannerView *)banner {
    banner.bounds = CGRectMake(0, 0, self.view.bounds.size.width, banner.bounds.size.height); banner.center = CGPointMake(self.view.bounds.size.width/2.0, self.view.bounds.size.height - banner.bounds.size.height/2.0);
    banner.transform = CGAffineTransformMakeTranslation(0, banner.bounds.size.height); [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1]; banner.transform = CGAffineTransformIdentity; [UIView commitAnimations];
}
-(void)slideOutDidStop:(NSString *)animationID finished:(NSNumber *)finished context: (void *)context
    {
        [self.bannerView removeFromSuperview];
        self.bannerView.delegate = nil; self.bannerView = nil;
    }
    
- (void)slideOutBannerView:(IPBannerView*)banner {
        banner.center = CGPointMake(self.view.bounds.size.width/2.0, self.view.bounds.size.height - banner.bounds.size.height/2.0);
        [UIView beginAnimations:@"nil" context:nil];
        [UIView setAnimationDuration:1];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(slideOutDidStop:finished:context:)]; banner.transform = CGAffineTransformMakeTranslation(0, banner.bounds.size.height); [UIView commitAnimations];
    }
- (NSString *)publisherIdForIPBannerView:(IPBannerView *)banner
{
    
    
    return @"Enter your publisherId";
}
- (void)IPBannerViewDidLoadIPAd:(IPBannerView *)banner {
    NSLog(@"IP Banner: did load ad");
    [self slideInBannerView:banner]; }
- (void)IPBannerViewDidLoadRefreshedAd:(IPBannerView *)banner
{
    NSLog(@"IP Banner: Received a 'refreshed' advert");
    if (![self isBannerViewInHiearchy]) {
        [self slideInBannerView:banner]; }
    else
    {
        banner.transform = CGAffineTransformIdentity; [UIView beginAnimations:@"IP" context:nil]; [UIView setAnimationDuration:1]; banner.transform = CGAffineTransformIdentity; [UIView commitAnimations];
    }
}
- (void)IPBannerView:(IPBannerView *)banner didFailToReceiveAdWithError: (NSError *)error
{
    NSLog(@"IP Banner: did fail to load ad: %@", [error localizedDescription]); [self slideOutBannerView:bannerView];
}
-(void)IPBannerViewActionWillPresent:(IPBannerView *)banner {
    NSLog(@"IP Banner: will present");
}


- (IBAction)Interstitial:(id)sender
{
    if((self.videoInterstitialViewController))
    {
        if ([self isBannerViewInHiearchy]) {
            [self slideOutBannerView:self.bannerView];
        }
        self.videoInterstitialViewController.enableInterstitialAds = YES; [self.videoInterstitialViewController requestAd];
    }
}

- (NSString*)publisherIdForIPVideoInterstitialView:(IPVideoInterstitialViewController
                                                    *)videoInterstitial {
    return @"Enter your publisherId";
}
- (void)IPVideoInterstitialViewDidLoadIPAd:(IPVideoInterstitialViewController *)videoInterstitial advertTypeLoaded:(IPAdType)advertType
{
    NSLog(@"IP Interstitial: did load ad"); [videoInterstitial presentAd:advertType];
}
-(void)IPVideoInterstitialView:(IPVideoInterstitialViewController *)videoInterstitial didFailToReceiveAdWithError:(NSError *)error
{
    NSLog(@"IP Interstitial: did fail to load ad: %@", [error localizedDescription]);
}
-(void)IPVideoInterstitialViewDidDismissScreen:(IPVideoInterstitialViewController *)videoInterstitial
{
    NSLog(@"IP Interstitial: did dismiss screen"); }
-(void)IPVideoInterstitialViewWasClicked:(IPVideoInterstitialViewController *)videoInterstitial {
    NSLog(@"IP Interstitial: was clicked"); }

@end
