//
//  ViewController.h
//  Demo
//
//  Created by Macmini - Vertoz on 9/21/15.
//  Copyright (c) 2015 Macmini - Vertoz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ipsdk/ipsdk.h>

@interface ViewController : UIViewController<IPBannerViewDelegate,IPVideoInterstitialViewControllerDelegate>
- (IBAction)Banner:(id)sender;

- (IBAction)Interstitial:(id)sender;
@property(strong,nonatomic) IPBannerView *bannerView;
@property (nonatomic, strong) IPVideoInterstitialViewController
*videoInterstitialViewController;

@end

