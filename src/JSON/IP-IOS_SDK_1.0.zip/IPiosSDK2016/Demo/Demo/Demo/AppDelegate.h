//
//  AppDelegate.h
//  Demo
//
//  Created by Macmini - Vertoz on 9/21/15.
//  Copyright (c) 2015 Macmini - Vertoz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

