//
//  main.m
//  Demo
//
//  Created by Macmini - Vertoz on 9/21/15.
//  Copyright (c) 2015 Macmini - Vertoz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
